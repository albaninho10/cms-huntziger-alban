<?php

brite_theme()->get( 'sidebar' )->render();
