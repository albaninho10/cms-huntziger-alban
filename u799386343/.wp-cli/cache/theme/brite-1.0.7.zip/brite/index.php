<?php

get_header();

brite_theme()->get( 'main' )->render();

get_footer();
