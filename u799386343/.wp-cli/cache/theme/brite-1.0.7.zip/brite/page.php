<?php get_header(); ?>
<?php brite_theme()->get( 'content' )->render(); ?>
<?php get_footer();
