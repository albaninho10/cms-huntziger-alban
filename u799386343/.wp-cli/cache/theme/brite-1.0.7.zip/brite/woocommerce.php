<?php

get_header();
brite_theme()->get( 'main-woo' )->render();
get_footer();
