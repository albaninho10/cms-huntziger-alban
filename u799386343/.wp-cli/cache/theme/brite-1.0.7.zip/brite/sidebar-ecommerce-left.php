<?php

brite_theme()->get( 'sidebar' )->render(array(
    'id' => 'ecommerce',
    'type' => 'left'
));
