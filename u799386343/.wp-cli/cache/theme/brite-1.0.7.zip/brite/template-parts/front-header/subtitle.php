<div data-colibri-id="1833-h28" class="h-text h-text-component style-348 style-local-1833-h28 position-relative h-element">
  <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
  <div>
    <p>
      <?php $component->printSubtitle(); ?>
    </p>
  </div>
</div>
