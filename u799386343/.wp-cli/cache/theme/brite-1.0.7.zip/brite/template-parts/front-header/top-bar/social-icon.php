<div class="social-icon-container d-inline-flex">
  <div class="icon-container h-social-icon h-global-transition">
    <div class="h-icon-svg" style="width: 100%; height: 100%;">
      <?php $icon = \ColibriWP\Theme\View::getData( 'icon' ); if (isset($icon['content'])) echo $icon['content'] ?>
    </div>
  </div>
</div>
