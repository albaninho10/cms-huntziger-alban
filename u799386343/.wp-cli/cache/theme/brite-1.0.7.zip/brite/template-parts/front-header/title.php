<div data-colibri-id="1833-h27" class="h-global-transition-all h-heading style-27 style-local-1833-h27 position-relative h-element">
  <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
  <div class="h-heading__outer style-27 style-local-1833-h27">
    <h1>
      <?php $component->printTitle(); ?>
    </h1>
  </div>
</div>
