<div data-colibri-id="1846-m16" class="h-row-container gutters-row-lg-0 gutters-row-md-0 gutters-row-0 gutters-row-v-lg-0 gutters-row-v-md-0 gutters-row-v-0 style-119 style-local-1846-m16 position-relative">
  <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-0 gutters-col-md-0 gutters-col-0 gutters-col-v-lg-0 gutters-col-v-md-0 gutters-col-v-0">
    <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-120-outer style-local-1846-m17-outer">
      <div data-colibri-id="1846-m17" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-120 style-local-1846-m17 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-auto align-self-lg-center align-self-md-center align-self-center">
          <div data-colibri-id="1846-m18" class="style-121 style-local-1846-m18 position-relative h-element">
            <div class="archive-nav-button h-global-transition-all">
              <?php brite_archive_nav_button(array (
                'type' => 'prev',
                'next_label' => __('Next', 'brite'),
                'prev_label' => __('Previous', 'brite'),
              )); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="h-column h-column-container d-flex h-col-lg h-col-md h-col style-122-outer style-local-1846-m19-outer">
      <div data-colibri-id="1846-m19" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-2 v-inner-md-2 v-inner-2 style-122 style-local-1846-m19 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-center align-self-md-center align-self-center">
          <div data-colibri-id="1846-m20" class="style-123 style-local-1846-m20 position-relative h-element">
            <div class="h-global-transition-all">
              <?php brite_archive_pagination(); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-124-outer style-local-1846-m21-outer">
      <div data-colibri-id="1846-m21" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-124 style-local-1846-m21 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-auto align-self-lg-center align-self-md-center align-self-center">
          <div data-colibri-id="1846-m22" class="style-125 style-local-1846-m22 position-relative h-element">
            <div class="archive-nav-button h-global-transition-all">
              <?php brite_archive_nav_button(array (
                'type' => 'next',
                'next_label' => __('Next', 'brite'),
                'prev_label' => __('Back', 'brite'),
              )); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
