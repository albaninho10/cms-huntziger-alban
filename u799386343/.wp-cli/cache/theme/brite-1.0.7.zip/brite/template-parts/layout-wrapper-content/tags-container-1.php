<div data-colibri-id="1843-m14" class="h-row-container gutters-row-lg-0 gutters-row-md-0 gutters-row-0 gutters-row-v-lg-0 gutters-row-v-md-0 gutters-row-v-0 style-82 style-local-1843-m14 position-relative">
  <div class="h-row justify-content-lg-start justify-content-md-start justify-content-start align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-0 gutters-col-md-0 gutters-col-0 gutters-col-v-lg-0 gutters-col-v-md-0 gutters-col-v-0">
    <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-83-outer style-local-1843-m15-outer">
      <div data-colibri-id="1843-m15" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-2 v-inner-md-2 v-inner-2 style-83 style-local-1843-m15 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-auto align-self-lg-start align-self-md-start align-self-start">
          <div data-colibri-id="1843-m16" class="h-icon style-343 style-local-1843-m16 position-relative h-element">
            <span class="h-svg-icon h-icon__icon style-343-icon style-local-1843-m16-icon">
              <!--Icon by Icons8 Line Awesome (https://icons8.com/line-awesome)-->
              <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" id="tag" viewBox="0 0 512 545.5">
                <path d="M256 112h176v176l-4.5 5L243 475.5l-11 11-11.5-11-152-152-11-11.5 11-11L251 116.5zm13.5 32l-167 168L232 441.5l168-167V144H269.5zm82.5 32c8.837 0 16 7.163 16 16s-7.163 16-16 16-16-7.163-16-16 7.163-16 16-16z"></path>
              </svg>
            </span>
          </div>
        </div>
      </div>
    </div>
    <div class="h-column h-column-container d-flex h-col-lg h-col-md h-col style-341-outer style-local-1843-m17-outer">
      <div data-colibri-id="1843-m17" class="d-flex h-flex-basis h-column__inner h-px-lg-2 h-px-md-2 h-px-2 v-inner-lg-2 v-inner-md-2 v-inner-2 style-341 style-local-1843-m17 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100 align-self-lg-start align-self-md-start align-self-start">
          <div data-colibri-id="1843-m18" class="h-blog-tags empty-preview style-84 style-local-1843-m18 position-relative h-element">
            <div class="h-global-transition-all">
              <?php brite_post_tags(array (
                'prefix' => '',
              )); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
