<div data-colibri-id="1843-m24" class="h-row-container gutters-row-lg-0 gutters-row-md-0 gutters-row-0 gutters-row-v-lg-0 gutters-row-v-md-0 gutters-row-v-0 style-90 style-local-1843-m24 position-relative">
  <div class="h-row justify-content-lg-center justify-content-md-center justify-content-center align-items-lg-stretch align-items-md-stretch align-items-stretch gutters-col-lg-0 gutters-col-md-0 gutters-col-0 gutters-col-v-lg-0 gutters-col-v-md-0 gutters-col-v-0">
    <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-91-outer style-local-1843-m25-outer">
      <div data-colibri-id="1843-m25" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-91 style-local-1843-m25 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-auto align-self-lg-center align-self-md-center align-self-center">
          <div data-colibri-id="1843-m26" class="post-nav-button hide-title style-92 style-local-1843-m26 position-relative h-element">
            <div class="h-global-transition-all">
              <?php brite_post_nav_button(array (
                'type' => 'prev',
                'prev_post' => __('Previous post', 'brite'),
                'next_post' => __('Next post:', 'brite'),
                'show_title' => false,
                'title_length' => 40,
              )); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="h-column h-column-container d-flex h-col-lg h-col-md h-col style-93-outer style-local-1843-m27-outer">
      <div data-colibri-id="1843-m27" class="d-flex h-flex-basis h-column__inner h-ui-empty-state-container h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-93 style-local-1843-m27 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-100"></div>
      </div>
    </div>
    <div class="h-column h-column-container d-flex h-col-lg-auto h-col-md-auto h-col-auto style-94-outer style-local-1843-m28-outer">
      <div data-colibri-id="1843-m28" class="d-flex h-flex-basis h-column__inner h-px-lg-0 h-px-md-0 h-px-0 v-inner-lg-0 v-inner-md-0 v-inner-0 style-94 style-local-1843-m28 position-relative">
        <div class="w-100 h-y-container h-column__content h-column__v-align flex-basis-auto align-self-lg-center align-self-md-center align-self-center">
          <div data-colibri-id="1843-m29" class="post-nav-button hide-title style-95 style-local-1843-m29 position-relative h-element">
            <div class="h-global-transition-all">
              <?php brite_post_nav_button(array (
                'type' => 'next',
                'prev_post' => __('Previous post:', 'brite'),
                'next_post' => __('Next post', 'brite'),
                'show_title' => false,
                'title_length' => 30,
              )); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
