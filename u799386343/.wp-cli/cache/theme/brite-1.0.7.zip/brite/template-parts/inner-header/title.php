<div data-colibri-id="1837-h27" class="page-title style-58 style-local-1837-h27 position-relative h-element">
  <?php $component = \ColibriWP\Theme\View::getData( 'component' ); ?>
  <div class="h-page-title__outer style-58-outer style-local-1837-h27-outer">
    <div class="h-global-transition-all">
      <?php brite_page_title(array (
        'tag' => 'h1',
      )); ?>
    </div>
  </div>
</div>
